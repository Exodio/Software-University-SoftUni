export { default } from "./Post";
