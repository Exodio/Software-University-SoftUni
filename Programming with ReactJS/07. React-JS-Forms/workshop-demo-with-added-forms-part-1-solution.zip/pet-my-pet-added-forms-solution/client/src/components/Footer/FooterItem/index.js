import FooterItem from "./FooterItem";

export default FooterItem;
