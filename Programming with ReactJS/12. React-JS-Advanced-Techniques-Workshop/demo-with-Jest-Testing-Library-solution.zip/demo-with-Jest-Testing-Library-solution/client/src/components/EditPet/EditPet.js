import { Component } from "react";

import * as petsService from "../../services/petsService";

import PetFormView from "../PetFormView/PetFormView";

import isAuth from "../../hoc/isAuth";

class EditPet extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      description: "",
    };
  }

  componentDidMount() {
    // petsService.getOne(this.props.match.params.petId)
    //     .then(pet => {
    //         this.setState(pet);
    //     });
  }

  onEditSubmitHandler(e) {
    console.log(e);
  }

  render() {
    return (
      <PetFormView
        onSubmitHandler={this.onEditSubmitHandler.bind(this)}
        petName={this.state.name}
        setPetName={(name) => this.setState({ name })}
        petDescription={this.state.description}
        setPetDescription={(description) => this.setState({ description })}
      />
    );
  }
}

export default isAuth(EditPet); 