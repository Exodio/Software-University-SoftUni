import React, { useReducer } from "react";

import Toolbar from "./Toolbar";
import ThemeContext from "./ThemeContext";

const AdvancedApp = ({}) => {
  // const [theme, setTheme] = useState({
  //     color: "dark",
  //     size: "normal",
  //     font: "default",
  // });

  const themeReducer = (state, action) => {
    switch (action.type) {
      case "TOGGLE_COLOR":
        return { ...state, color: state.color == "dark" ? "light" : "dark" };
      case "INCREASE_SIZE":
        return { ...state, font: action.payload };
      case "CHANGE_FONT":
        return { ...state, size: state.size + 1 };
      default:
        return state;
    }
  };

  const [theme, dispatch] = useReducer(themeReducer, {
    color: "dark",
    size: "normal",
    font: "default",
  });

  return (
    <ThemeContext.Provider value={[theme, dispatch]}>
      <Toolbar />
    </ThemeContext.Provider>
  );
};

export default AdvancedApp;