import ThemeButton from "./ThemeButton";

function Toolbar(props) {
  return (
    <div>
      <ThemeButton />
    </div>
  );
}

export default Toolbar;