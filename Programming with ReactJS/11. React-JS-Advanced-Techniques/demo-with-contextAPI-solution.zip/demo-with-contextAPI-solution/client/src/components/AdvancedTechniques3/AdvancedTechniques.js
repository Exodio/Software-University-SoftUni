import AdvancedApp from "./AdvancedApp";
// const ThemeContext = React.createContext();

function AdvancedTechniques() {
  return <AdvancedApp />;
}

export default AdvancedTechniques;
