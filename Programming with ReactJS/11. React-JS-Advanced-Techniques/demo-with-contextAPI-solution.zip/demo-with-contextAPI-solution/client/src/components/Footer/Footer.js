const Footer = () => {
    return (
        <footer id="site-footer">
            <p>@PetMyPet</p>
        </footer>
    );
};

export default Footer;


