import ThemeButton from "./ThemeButton";

function Toolbar() {
  return (
    <div>
      <ThemeButton />
    </div>
  );
}

export default Toolbar;