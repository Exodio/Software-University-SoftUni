const baseUrl = "http://localhost:5000";

export default {
  posts: `${baseUrl}/posts`,
};
