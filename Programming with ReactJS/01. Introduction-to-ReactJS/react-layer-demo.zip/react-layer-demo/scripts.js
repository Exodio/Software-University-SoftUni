const domElement = document.createElementById('root');

//const reactElement = React.createElement('h1', {}, 'Hello from React element');

// React.createElement(
//     'header', {},
//     React.createElement('h1', {}, 'Hello from React element'),
//     React.createElement('h2', {}, 'The best Framework ever'),

// );

// const reactJsxElement = React.createElement('h1', {}, 'Hello from React JSX element');
// const reactJsxElement = <h1>Hello from React JSX element</h1>;

// const reactJsxElement = <heder>
//     <h1>Hello from React Element</h1>
//     <h2>The best Framework Ever</h2>
// </heder>;

const reactJsxElement = (
<heder>
    <h1>Hello from React Element</h1>
    <h2>The best Framework Ever</h2>
</heder>
);

ReactDOM.render(reactElement, domElement);