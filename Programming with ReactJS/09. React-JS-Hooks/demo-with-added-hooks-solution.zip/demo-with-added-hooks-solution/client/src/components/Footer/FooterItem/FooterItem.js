import style from './FooterItem.module.css';

const FooterItem = (props) => {
    return (
        <li className="listItem">
            <a href="#" className={style.footerListItem}>{props.children}</a>
        </li>
    );
}

export default FooterItem;