import style from './Header.module.css';
import NavigationItem from './NavigationItem';
import { Link, NavLink } from 'react-router-dom';

const Header = () => {
    return (
      // <nav className={style.navigation}>
      //   <ul>
      //     <li className="listItem"><img src="/white-origami-bird.png" alt="white origami" /></li>
      //     <Link to="/"><NavigationItem>Home</NavigationItem></Link>
      //     <Link to="/about"><NavigationItem>About</NavigationItem></Link>
      //     <Link to="/contact-us"><NavigationItem>Contact Us</NavigationItem></Link>
      //     <Link to="/about/name1"><NavigationItem>Going to 4</NavigationItem></Link>
      //     <Link to="/about/name2"><NavigationItem>Going to 5</NavigationItem></Link>
      //     <Link to="/about/name3"><NavigationItem>Going to 6</NavigationItem></Link>
      //     <Link to="/about/name4"><NavigationItem>Going to 7</NavigationItem></Link>
      //     <Link to="/about/name5"><NavigationItem>Going to 8</NavigationItem></Link>
      //     <Link to="/about/name6"><NavigationItem>Going to 9</NavigationItem></Link>
      //     <Link to="/about/name7"><NavigationItem>Going to 10</NavigationItem></Link>
      //     <Link to="/about/name8"><NavigationItem>Going to 11</NavigationItem></Link>
      //   </ul>
      // </nav>
        <nav className={style.navigation}>
            <ul>
                <li className="listItem"><img src="/white-origami-bird.png" alt="white origami" /></li>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/"><NavigationItem>Home</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about"><NavigationItem>About</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/contact-us"><NavigationItem>Contact Us</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name1"><NavigationItem>Going to 4</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name2"><NavigationItem>Going to 5</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name3"><NavigationItem>Going to 6</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name4"><NavigationItem>Going to 7</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name5"><NavigationItem>Going to 8</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name6"><NavigationItem>Going to 9</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name7"><NavigationItem>Going to 10</NavigationItem></NavLink>
                <NavLink activeClassName="active-navigation-item" exact={true} to="/about/name8"><NavigationItem>Going to 11</NavigationItem></NavLink>
            </ul>
        </nav>
    );
};

export default Header;