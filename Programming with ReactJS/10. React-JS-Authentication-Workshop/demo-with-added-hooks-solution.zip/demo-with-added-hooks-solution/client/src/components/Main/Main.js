//import {Fragment} from "react";
import "./Main.css";
import Post from "../Post";

const Main = ({ posts }) => {
  return (
    <main className="main-container">

      <h1>Some Heading</h1>

      <div className="posts">
        {posts.map((x) => (
          <Post //post={x}; //if too many lines occur, deligate as followed
          key={x.id}
          content={x.content}
          author={x.author}
          />
        ))}
      </div>

    </main>
  );
}

export default Main;
