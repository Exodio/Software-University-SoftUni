const ContactUs = () => (
  <main className="main-container">
    <h1>Contact Us Page</h1>
  </main>
);

export default ContactUs;
